"""
I tried to understand the integration testing but couldn't fully understand the implementation in the snake game.
I did however try to create the structure of a project with it's tests.
"""